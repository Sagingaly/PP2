class clas():
    def getstring(self):
        self.a = input()

    def printstring(self):
        print(self.a.upper())

g = clas()

g.getstring()
g.printstring()